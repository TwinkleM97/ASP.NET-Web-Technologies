﻿using StudentsApp.Entities;


namespace StudentsApp.Models
{
    public class StudentsViewModel
    {
        public List<Student> Students { get; set; } = new List<Student>(); // List of students
        public string[] TabHeaders { get; set; } = new string[0]; // Array of tab headers
        public string CurrentTab { get; set; } = string.Empty; // Currently active tab 
        public Student NewStudent { get; set; } = new Student(); // NewStudent object
    }
}
