﻿using Microsoft.AspNetCore.Mvc;

using StudentsApp.Entities;
using StudentsApp.Models;
using StudentsApp.Services;


namespace StudentsApp.Controllers
{
    [Route("students")] // Enabling attribute routing
    public class StudentController : Controller
    {
        private IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }
        // GET: /students/{status?}
        [HttpGet("{status?}")]
        public IActionResult Items(string status)
        {
            List<Student> students;

            // If the status is empty, null, or "All", get all of the students
            if (string.IsNullOrEmpty(status) || status.Equals("All", StringComparison.OrdinalIgnoreCase))
            {
                students = _studentService.GetAllStudents();
                status = "All"; // Default Status will be ALL
            }
            else
            {
                // Getting students by their status
                students = _studentService.GetStudentsByStatus(status);
            }

            // View model
            var viewModel = new StudentsViewModel
            {
                Students = students,
                TabHeaders = _studentService.GetAllStatuses().ToArray(), //   Returns all statuses
                CurrentTab = status,
                NewStudent = new Student() //  Student object created
            };

            return View("Items", viewModel);
        }

        // POST: /students
        [HttpPost]
        public IActionResult AddStudent(StudentsViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Add the new student using the service
                _studentService.AddStudent(model.NewStudent);
                return RedirectToAction("Items", new { status = model.CurrentTab }); // Redirecting back to Items
            }

            // Re-render the Items view with the model if the model state is invalid
            model.TabHeaders = _studentService.GetAllStatuses().ToArray();
            model.CurrentTab = model.CurrentTab;
            return View("Items", model);
        }
    }
}