﻿namespace StudentsApp.Entities
{
    public class Student
    {
        public int Id { get; set; }

        public string EnrollmentStatus { get; set; }

        public string Name { get; set; }
    }
}
