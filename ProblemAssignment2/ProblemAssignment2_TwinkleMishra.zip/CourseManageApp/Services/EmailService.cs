﻿using CourseManageApp.Models;
using System.Net.Mail;
using System.Net;

namespace CourseManageApp.Services
{
    public class EmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task SendEnrollmentConfirmationEmail(Student student, Course course, string confirmationUrl)
        {
            var smtpServer = _configuration["EmailSettings:SmtpServer"];
            var smtpPort = int.Parse(_configuration["EmailSettings:SmtpPort"]);
            var smtpUsername = _configuration["EmailSettings:SmtpUsername"];
            var smtpPassword = _configuration["EmailSettings:SmtpPassword"];

            var mailMsg = new MailMessage
            {
                From = new MailAddress(smtpUsername),
                Subject = $"Enrollment Confirmation for {course.Name} required",
                Body = $@"
        <p>Hello {student.Name},</p>
        <p>Your request to enroll in the course <strong>{course.Name}</strong> in room <strong>{course.RoomNumber}</strong> starting from <strong>{course.StartDate}</strong> with instructor <strong>{course.Instructor}</strong> has been received.</p>
        <p>We are pleased to have you in the course! Please <a href='{confirmationUrl}'>confirm your enrollment</a> soon, it would be highly appreciated!!</p>
        <p>Sincerely,</p>
        <p>Course Manager App</p>",
                IsBodyHtml = true,
            };
            mailMsg.To.Add(student.Email);

            using var smtpClient = new SmtpClient(smtpServer, smtpPort)
            {
                Credentials = new NetworkCredential(smtpUsername, smtpPassword),
                EnableSsl = true
            };

            await smtpClient.SendMailAsync(mailMsg);
        }
    }
    }