﻿using System.ComponentModel.DataAnnotations;

namespace CourseManageApp.Models
{
    public class Course
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Course name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Instructor's name is required")]
        public string Instructor { get; set; }

        [Required(ErrorMessage = "Start date is required")]
        [Display(Name = "Start date")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Room number is required")]
        [RegularExpression(@"^[0-9][A-Z][0-9]{2}$", ErrorMessage = "Room number must be in format: 2C09")]
        [Display(Name = "Room number")]
        public string RoomNumber { get; set; }

        public ICollection<Student> Students { get; set; } = new List<Student>();
    }
}
