﻿namespace CourseManageApp.Models
{
    public class CourseManagementViewModel
    {
        public Course Course { get; set; }
        public int NotSentCount { get; set; }
        public int SentCount { get; set; }
        public int ConfirmedCount { get; set; }
        public int DeclinedCount { get; set; }
    }

    }

