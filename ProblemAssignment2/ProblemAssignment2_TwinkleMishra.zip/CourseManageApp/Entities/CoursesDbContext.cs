﻿using CourseManageApp.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace CourseManageApp.Entities
{
    public class CoursesDbContext : DbContext
    {
        public CoursesDbContext(DbContextOptions<CoursesDbContext> options)
            : base(options)
        {
        }

        public DbSet<Course> Courses { get; set; }
        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Course>()
                .HasMany(c => c.Students)
                .WithOne(s => s.Course)
                .HasForeignKey(s => s.CourseId);

            modelBuilder.Entity<Student>()
                .Property(s => s.Status)
                .HasConversion<string>();

            // Seeding data for Courses
            modelBuilder.Entity<Course>().HasData(
                new Course
                {
                    Id = 1,
                    Name = "Programming Microsoft Web Technologies",
                    Instructor = "Manny Singh",
                    StartDate = new DateTime(2024, 9, 15),
                    RoomNumber = "1C09"
                },
                new Course
                {
                    Id = 2,
                    Name = "Web Foundations",
                    Instructor = "Niloy Bizoid",
                    StartDate = new DateTime(2024, 1, 15),
                    RoomNumber = "4G15"
                },
                new Course
                {
                    Id = 3,
                    Name = "Systems Development",
                    Instructor = "Regan Benner",
                    StartDate = new DateTime(2023, 12, 19),
                    RoomNumber = "2F09"
                }
            );
            //Seeding Data for students
            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    Id = 1,
                    Name = "Nanno NG",
                    Email = "nanno@gmail.com",
                    CourseId = 1,
                    Status = EnrollmentStatus.ConfirmationMessageNotSent
                },
                new Student
                {
                    Id = 2,
                    Name = "Taylor Swift",
                    Email = "taylorswift13@gmail.com",
                    CourseId = 2,
                    Status = EnrollmentStatus.ConfirmationMessageNotSent
                }
            );
        }
    }
}
