using CourseManageApp.Entities;
using CourseManageApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CourseManageApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly CoursesDbContext _context;
        private const string FirstVisitCookieKey = "FirstVisit";

        public HomeController(CoursesDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            if (!Request.Cookies.ContainsKey(FirstVisitCookieKey))
            {
                var cookieOptions = new CookieOptions
                {
                    Expires = DateTime.Now.AddYears(1)
                };
                Response.Cookies.Append(FirstVisitCookieKey, DateTime.Now.ToString("O"), cookieOptions);
                ViewBag.WelcomeMessage = "Hey, welcome to the Course Manager App!";
            }
            else
            {
                var firstVisit = DateTime.Parse(Request.Cookies[FirstVisitCookieKey]);
                ViewBag.WelcomeMessage = $"Welcome back! You first used this app on: {firstVisit:M/d/yyyy h:mm:ss tt}";
            }

            return View();
        }
    }
}
