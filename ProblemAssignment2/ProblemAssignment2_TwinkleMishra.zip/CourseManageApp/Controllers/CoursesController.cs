﻿using CourseManageApp.Entities;
using CourseManageApp.Models;
using CourseManageApp.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace CourseManageApp.Controllers
{
    public class CoursesController : Controller
    {
        private readonly CoursesDbContext _context;
        private readonly EmailService _emailService;
        private readonly ILogger<CoursesController> _logger;

        public CoursesController(CoursesDbContext context, EmailService emailService, ILogger<CoursesController> logger)
        {
            _context = context;
            _emailService = emailService;
            _logger = logger;
        }
        public async Task<IActionResult> Index()
        {
            var courses = await _context.Courses
         .Include(c => c.Students)  // loading Students collection
         .ToListAsync();

            return View(courses);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Course course)
        {
            if (ModelState.IsValid)
            {
                _context.Add(course);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(course);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Courses.FindAsync(id);
            if (course == null)
            {
                return NotFound();
            }
            return View(course);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Course course)
        {
            if (id != course.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(course);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CourseExists(course.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(course);
        }


        [HttpPost]
        public async Task<IActionResult> CreateStudent(int courseId, string name, string email)
        {
            var course = await _context.Courses.FindAsync(courseId);
            if (course == null)
            {
                return NotFound();
            }

            var student = new Student
            {
                Name = name,
                Email = email,
                CourseId = courseId
            };

            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Manage), new { id = courseId });
        }

        [HttpPost]
        public async Task<IActionResult> SendConfirmations(int courseId, int? studentId)
        {
            try
            {
                // First, get the course with a separate query
                var course = await _context.Courses
                    .FirstOrDefaultAsync(c => c.Id == courseId);

                if (course == null)
                {
                    return Json(new { success = false, error = "Sorry, Course not found" });
                }

                if (studentId.HasValue)
                {
                    // Send confirmation to a single student
                    var student = await _context.Students
                        .FirstOrDefaultAsync(s => s.Id == studentId.Value && s.CourseId == courseId);

                    if (student == null)
                    {
                        return Json(new { success = false, error = "Sorry, Student not found" });
                    }

                    string confirmationUrl = Url.Action("ConfirmEnrollment", "Courses",
                        new { courseId = course.Id, studentId = student.Id },
                        Request.Scheme);

                    try
                    {
                        await _emailService.SendEnrollmentConfirmationEmail(student, course, confirmationUrl);

                        // Update student status
                        student.Status = EnrollmentStatus.ConfirmationMessageSent;
                        await _context.SaveChangesAsync();

                        return Json(new { success = true });
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Failed to send email to student {StudentId}", student.Id);
                        return Json(new { success = false, error = "Failed to send confirmation email." });
                    }
                }
                else
                {
                    // Send confirmations to all students in the course
                    var students = await _context.Students
                        .Where(s => s.CourseId == courseId &&
                               s.Status == EnrollmentStatus.ConfirmationMessageNotSent)
                        .ToListAsync();

                    if (!students.Any())
                    {
                        return Json(new { success = false, error = "No pending invitations to send." });
                    }

                    var successCount = 0;
                    var errorCount = 0;

                    foreach (var student in students)
                    {
                        string confirmationUrl = Url.Action("ConfirmEnrollment", "Courses",
                            new { courseId = course.Id, studentId = student.Id },
                            Request.Scheme);

                        try
                        {
                            await _emailService.SendEnrollmentConfirmationEmail(student, course, confirmationUrl);
                            student.Status = EnrollmentStatus.ConfirmationMessageSent;
                            successCount++;
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "Failed to send email to student {StudentId}", student.Id);
                            errorCount++;
                        }
                    }

                    if (successCount > 0)
                    {
                        await _context.SaveChangesAsync();
                    }

                    if (errorCount > 0)
                    {
                        return Json(new
                        {
                            success = true,
                            warning = $"Sent {successCount} emails, failed to send {errorCount} emails"
                        });
                    }

                    return Json(new { success = true });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in SendConfirmations method");
                return Json(new { success = false, error = "An error occurred while sending confirmations" });
            }
        }
    
        private bool CourseExists(int id)
        {
            return _context.Courses.Any(e => e.Id == id);
        }


        
        [HttpGet]
        public IActionResult ConfirmEnrollment(int courseId, int studentId)
        {
            var student = _context.Students.FirstOrDefault(s => s.Id == studentId);
            if (student == null)
                return NotFound();

            var course = _context.Courses.FirstOrDefault(c => c.Id == courseId);
            if (course == null)
                return NotFound();

            student.Course = course;  // Assuming that the student has a reference to the course
            return View(student);  // Pass the student model to the view
        }

        //Handles the confirmation response (Yes/No)
        [HttpPost]
        public async Task<IActionResult> ConfirmEnrollmentResponse(int courseId, int studentId, string enrollmentResponse)
        {
            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.Id == studentId);
            if (student == null)
                return NotFound();

            var course = await _context.Courses
                .Include(c => c.Students)  // Include students to ensure proper tracking
                .FirstOrDefaultAsync(c => c.Id == courseId);
            if (course == null)
                return NotFound();

            // Updating student status based on the response
            if (enrollmentResponse == "Yes")
            {
                student.Status = EnrollmentStatus.EnrollmentConfirmed;
                student.CourseId = courseId;
            }
            else if (enrollmentResponse == "No")
            {
                student.Status = EnrollmentStatus.EnrollmentDeclined;
            }

            try
            {
                await _context.SaveChangesAsync();

                // Log the status change
                _logger.LogInformation(
                    "Student {StudentId} {Action} enrollment for Course {CourseId}",
                    studentId,
                    enrollmentResponse == "Yes" ? "confirmed" : "declined",
                    courseId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving enrollment response for Student {StudentId}", studentId);
                // You might want to handle this error appropriately
            }

            // Update the view based on the response
            return RedirectToAction("ThankYou", new { confirmed = enrollmentResponse == "Yes" });
        }

      
        public IActionResult ThankYou(bool confirmed)
        {
            ViewData["Confirmed"] = confirmed;
            return View();
        }

        public async Task<IActionResult> Manage(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Courses
                .Include(c => c.Students)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
            {
                return NotFound();
            }

            // Counting the number of confirmations and declined responses
            var notSentCount = course.Students.Count(s => s.Status == EnrollmentStatus.ConfirmationMessageNotSent);
            var sentCount = course.Students.Count(s => s.Status == EnrollmentStatus.ConfirmationMessageSent);
            var confirmedCount = course.Students.Count(s => s.Status == EnrollmentStatus.EnrollmentConfirmed);
            var declinedCount = course.Students.Count(s => s.Status == EnrollmentStatus.EnrollmentDeclined);

            var viewModel = new CourseManagementViewModel
            {
                Course = course,
                NotSentCount = notSentCount,
                SentCount = sentCount,
                ConfirmedCount = confirmedCount,
                DeclinedCount = declinedCount
            };

            return View(viewModel);
        }
    }
}