﻿using CourseManageApp.Entities;
using CourseManageApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CourseManageApp.Controllers
{
    public class EnrollmentController : Controller
    {
        private readonly CoursesDbContext _context;

        public EnrollmentController(CoursesDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Confirm(int studentId)
        {
            var student = await _context.Students
                .Include(s => s.Course)
                .FirstOrDefaultAsync(s => s.Id == studentId);

            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }

        [HttpPost]
        public async Task<IActionResult> SubmitResponse(int studentId, bool confirm)
        {
            var student = await _context.Students.FindAsync(studentId);
            if (student == null)
            {
                return NotFound();
            }

            student.Status = confirm ? EnrollmentStatus.EnrollmentConfirmed : EnrollmentStatus.EnrollmentDeclined;
            await _context.SaveChangesAsync();
            TempData["LastActionMessage"] = $"Student {student.Name} has {(confirm ? "confirmed" : "declined")} enrollment.";

            return RedirectToAction("Manage", "Courses", new { id = student.CourseId });
        }
    }
}