﻿using System.Net;
using System.Net.Mail;

// If Gmail is your primary email, then would recommend using a test address
// E.g. I have one that just adds ".consulting" to the end of my usual one.
string fromAddress = "YOUR-TEST-GMAIL-ADDRESS";
string toAddress = "TRY-YOUR-CONESTOGA-ADDRESS";

// NOTE: to make this work "2FA" must be turned on for gmail
// and then you add an app and they generate a password for use with that app
// see here: https://stackoverflow.com/questions/32260/sending-email-in-net-through-gmail
var smtpClient = new SmtpClient("smtp.gmail.com") {
    Port = 587,
    Credentials = new NetworkCredential(fromAddress, "YOUR-GENERATED-PASSWORD"),
    EnableSsl = true,
};

var mailMessage = new MailMessage() {
    From = new MailAddress(fromAddress),
    Subject = "A test of emailing from C#",
    Body = "<h1>Hello.</h1><p>Checkout <a href=\"https://www.google.ca\">Google</a>!!!!</p>",
    IsBodyHtml = true
};

mailMessage.To.Add(toAddress);

smtpClient.SendAsync(mailMessage, null);
