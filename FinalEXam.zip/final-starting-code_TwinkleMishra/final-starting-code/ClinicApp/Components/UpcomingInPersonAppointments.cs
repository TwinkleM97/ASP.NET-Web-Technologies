﻿using Clinic.Entities;
using ClinicApp.DataAccess;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ClinicApp.Components
{
    public class UpcomingInPersonAppointments : ViewComponent
    {
        private readonly ClinicScheduleDbContext _clinicScheduleDbContext;

        public UpcomingInPersonAppointments(ClinicScheduleDbContext clinicScheduleDbContext)
        {
            _clinicScheduleDbContext = clinicScheduleDbContext;
        }

        public IViewComponentResult Invoke(int numberOfAppointmentsToDisplay)
        {
            DateTime now = DateTime.Now;
            var appointments = _clinicScheduleDbContext.Appointments
                .Include(a => a.Schedule)
                .Where(a => a.AppointmentType == AppointmentTypeOptions.InPerson && a.AppointmentDate > now)
                .OrderBy(a => a.AppointmentDate)
                .Take(numberOfAppointmentsToDisplay)
                .ToList();

            var viewModel = new AppointmentsViewModel
            {
                Appointments = appointments,
                NumberOfAppointmentsToDisplay = numberOfAppointmentsToDisplay
            };

            return View(viewModel);
        }
    }
}
