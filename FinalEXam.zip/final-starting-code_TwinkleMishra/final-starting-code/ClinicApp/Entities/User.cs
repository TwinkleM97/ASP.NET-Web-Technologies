﻿using Microsoft.AspNetCore.Identity;

namespace ClinicApp.Entities
{
    public class User : IdentityUser
    {
        // TODO: add app-specific props
    }
}
