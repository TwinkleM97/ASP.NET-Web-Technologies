﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using ClinicApp.DataAccess;
using Clinic.Entities;
using ClinicApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace ClinicApp.Controllers
{
    public class ScheduleController : Controller
    {
        public ScheduleController(ClinicScheduleDbContext clinicScheduleDbContext)
        {
            _clinicScheduleDbContext = clinicScheduleDbContext;
        }

        [HttpGet("/schedules")]
        public IActionResult GetAllSchedules()
        {
            var schedules = _clinicScheduleDbContext.Schedules
                    .Include(s => s.Clinicians)
                    .Include(s => s.Appointments)
                    .OrderByDescending(s => s.DateCreated)
                    .ToList();

            return View("Items", schedules);
        }
        [Authorize]
        [HttpGet("/schedules/{id}")]
        public IActionResult GetScheduleById(int id)
        {
            var schedule = _clinicScheduleDbContext.Schedules
                .Include(s => s.Clinicians)
                .Include(s => s.Appointments)
                .FirstOrDefault(s => s.ScheduleId == id);

            if (schedule == null)
            {
                Console.WriteLine($"Schedule with ID {id} not found.");
                return NotFound();
            }

            var viewModel = new ScheduleDetailsViewModel
            {
                ActiveSchedule = schedule,
                NewClinician = new Clinician { ScheduleId = id },
                NewAppointment = new Appointment { ScheduleId = id },
                InPersonCount = schedule.Appointments.Count(a => a.AppointmentType == AppointmentTypeOptions.InPerson),
                PhoneCount = schedule.Appointments.Count(a => a.AppointmentType == AppointmentTypeOptions.Phone),
                VideoCount = schedule.Appointments.Count(a => a.AppointmentType == AppointmentTypeOptions.Video)
            };

            return View("Details", viewModel);
        }


        [Authorize]
        [HttpGet("/schedules/add-request")]
        public IActionResult GetAddScheduleRequest()
        {
            return View("AddSchedule", new Schedule());
        }
        [Authorize]
        [HttpPost("/schedules")]
        public IActionResult AddNewSchedule(Schedule schedule)
        {
            if (ModelState.IsValid)
            {
                _clinicScheduleDbContext.Schedules.Add(schedule);
                _clinicScheduleDbContext.SaveChanges();

                TempData["LastActionMessage"] = $"The schedule \"{schedule.Name}\" was added";

                return RedirectToAction("GetAllSchedules", "Schedule");
            }
            else
            {
                return View("AddSchedule", schedule);
            }
        }
        [Authorize]
        [HttpGet("/schedules/{id}/edit-request")]
        public IActionResult GetEditRequestById(int id)
        {
            var schedule = _clinicScheduleDbContext.Schedules.Find(id);
            return View("EditSchedule", schedule);
        }
        [Authorize]
        [HttpPost("/schedules/edit-requests")]
        public IActionResult ProcessEditRequest(Schedule schedule)
        {
            if (ModelState.IsValid)
            {
                _clinicScheduleDbContext.Schedules.Update(schedule);
                _clinicScheduleDbContext.SaveChanges();

                TempData["LastActionMessage"] = $"The schedule \"{schedule.Name}\" was updated";

                return RedirectToAction("GetAllSchedules", "Schedule");
            }
            else
            {
                return View("EditSchedule", schedule);
            }
        }
        [Authorize(Roles = "Admin")]
        [HttpGet("/schedules/{id}/delete-request")]
        public IActionResult GetDeleteRequestById(int id)
        {
            var schedule = _clinicScheduleDbContext.Schedules.Find(id);
            return View("DeleteConfirmation", schedule);
        }
        [Authorize(Roles = "Admin")]
        public IActionResult ProcessDeleteRequestById(int id)
        {
            var schedule = _clinicScheduleDbContext.Schedules.Find(id);

            _clinicScheduleDbContext.Schedules.Remove(schedule);
            _clinicScheduleDbContext.SaveChanges();

            TempData["LastActionMessage"] = $"The schedule \"{schedule.Name}\" was deleted";

            return RedirectToAction("GetAllSchedules", "Schedule");
        }
        [Authorize]
        [HttpGet]
        public IActionResult AddClinician(int scheduleId)
        {
            var schedule = _clinicScheduleDbContext.Schedules
                .FirstOrDefault(s => s.ScheduleId == scheduleId);

            if (schedule == null)
            {
                return NotFound();
            }

            // Return a view with a new clinician bound to the schedule
            var clinician = new Clinician
            {
                ScheduleId = scheduleId
            };

            return View(clinician); 
        }

        [Authorize]
        [HttpPost]
        public IActionResult AddClinician(Clinician clinician)
        {
            if (!ModelState.IsValid)
            {
                var schedule = _clinicScheduleDbContext.Schedules
                    .Include(s => s.Clinicians)
                    .Include(s => s.Appointments)
                    .FirstOrDefault(s => s.ScheduleId == clinician.ScheduleId);

                if (schedule == null)
                    return NotFound();

                var viewModel = new ScheduleDetailsViewModel
                {
                    ActiveSchedule = schedule,
                    NewClinician = clinician,
                    NewAppointment = new Appointment { ScheduleId = clinician.ScheduleId }
                };

                return View("Details", viewModel);
            }

            _clinicScheduleDbContext.Clinicians.Add(clinician);
            _clinicScheduleDbContext.SaveChanges();

            TempData["LastActionMessage"] = $"Clinician \"{clinician.FirstName} {clinician.LastName}\" was successfully added";
            return RedirectToAction("GetScheduleById", new { id = clinician.ScheduleId });
        }
        [Authorize]
        [HttpGet]
        public IActionResult AddAppointment(int scheduleId)
        {
            var schedule = _clinicScheduleDbContext.Schedules
                .FirstOrDefault(s => s.ScheduleId == scheduleId);

            if (schedule == null)
            {
                return NotFound();
            }

            // Returning a view with a new appointment bound to the schedule
            var appointment = new Appointment
            {
                ScheduleId = scheduleId
            };

            return View(appointment); 
        }
        [Authorize]
        [HttpPost]
        public IActionResult AddAppointment(Appointment appointment)
        {
            if (!ModelState.IsValid)
            {
                var schedule = _clinicScheduleDbContext.Schedules
                    .Include(s => s.Clinicians)
                    .Include(s => s.Appointments)
                    .FirstOrDefault(s => s.ScheduleId == appointment.ScheduleId);

                if (schedule == null)
                    return NotFound();

                var viewModel = new ScheduleDetailsViewModel
                {
                    ActiveSchedule = schedule,
                    NewAppointment = appointment,
                    NewClinician = new Clinician { ScheduleId = appointment.ScheduleId }
                };

                return View("Details", viewModel);
            }

            _clinicScheduleDbContext.Appointments.Add(appointment);
            _clinicScheduleDbContext.SaveChanges();

            TempData["LastActionMessage"] = $"The appointment for \"{appointment.PatientName}\" was added";
            return RedirectToAction("GetScheduleById", new { id = appointment.ScheduleId });
        }

        private ClinicScheduleDbContext _clinicScheduleDbContext;
    }
}

