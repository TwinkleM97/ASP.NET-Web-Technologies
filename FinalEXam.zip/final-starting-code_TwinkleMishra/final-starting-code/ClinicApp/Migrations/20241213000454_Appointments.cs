﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClinicApp.Migrations
{
    /// <inheritdoc />
    public partial class Appointments : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 12,
                column: "AppointmentDate",
                value: new DateTime(2024, 12, 13, 19, 4, 53, 828, DateTimeKind.Local).AddTicks(3772));

            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 13,
                column: "AppointmentDate",
                value: new DateTime(2024, 12, 15, 19, 4, 53, 828, DateTimeKind.Local).AddTicks(3839));

            migrationBuilder.InsertData(
                table: "Appointments",
                columns: new[] { "AppointmentId", "AppointmentDate", "AppointmentType", "PatientName", "ScheduleId" },
                values: new object[] { 14, new DateTime(2024, 12, 17, 19, 4, 53, 828, DateTimeKind.Local).AddTicks(3844), "InPerson", "Karl Marx", 3 });

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 19, 4, 53, 828, DateTimeKind.Local).AddTicks(4325));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 19, 4, 53, 828, DateTimeKind.Local).AddTicks(4336));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 14);

            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 12,
                column: "AppointmentDate",
                value: new DateTime(2024, 12, 13, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(8893));

            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 13,
                column: "AppointmentDate",
                value: new DateTime(2024, 12, 15, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(8970));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(9496));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(9509));
        }
    }
}
