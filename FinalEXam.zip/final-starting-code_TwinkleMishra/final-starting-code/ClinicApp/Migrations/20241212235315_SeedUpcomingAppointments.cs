﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClinicApp.Migrations
{
    /// <inheritdoc />
    public partial class SeedUpcomingAppointments : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 10,
                column: "AppointmentDate",
                value: new DateTime(2024, 12, 13, 18, 53, 14, 983, DateTimeKind.Local).AddTicks(3277));

            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 11,
                columns: new[] { "AppointmentDate", "AppointmentType" },
                values: new object[] { new DateTime(2024, 12, 15, 18, 53, 14, 983, DateTimeKind.Local).AddTicks(3355), "Video" });

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 18, 53, 14, 983, DateTimeKind.Local).AddTicks(3872));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 18, 53, 14, 983, DateTimeKind.Local).AddTicks(3884));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 10,
                column: "AppointmentDate",
                value: new DateTime(2024, 12, 13, 18, 49, 23, 949, DateTimeKind.Local).AddTicks(6611));

            migrationBuilder.UpdateData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 11,
                columns: new[] { "AppointmentDate", "AppointmentType" },
                values: new object[] { new DateTime(2024, 12, 15, 18, 49, 23, 949, DateTimeKind.Local).AddTicks(6679), "InPerson" });

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 18, 49, 23, 949, DateTimeKind.Local).AddTicks(7195));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 18, 49, 23, 949, DateTimeKind.Local).AddTicks(7207));
        }
    }
}
