﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ClinicApp.Migrations
{
    /// <inheritdoc />
    public partial class third : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 11);

            migrationBuilder.InsertData(
                table: "Appointments",
                columns: new[] { "AppointmentId", "AppointmentDate", "AppointmentType", "PatientName", "ScheduleId" },
                values: new object[,]
                {
                    { 12, new DateTime(2024, 12, 13, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(8893), "InPerson", "Future Patient 1", 1 },
                    { 13, new DateTime(2024, 12, 15, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(8970), "InPerson", "Future Patient 2", 2 }
                });

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(9496));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 19, 2, 26, 186, DateTimeKind.Local).AddTicks(9509));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Appointments",
                keyColumn: "AppointmentId",
                keyValue: 13);

            migrationBuilder.InsertData(
                table: "Appointments",
                columns: new[] { "AppointmentId", "AppointmentDate", "AppointmentType", "PatientName", "ScheduleId" },
                values: new object[,]
                {
                    { 10, new DateTime(2024, 12, 13, 18, 59, 54, 81, DateTimeKind.Local).AddTicks(1377), "InPerson", "Future Patient 1", 1 },
                    { 11, new DateTime(2024, 12, 15, 18, 59, 54, 81, DateTimeKind.Local).AddTicks(1452), "InPerson", "Future Patient 2", 2 }
                });

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 18, 59, 54, 81, DateTimeKind.Local).AddTicks(2070));

            migrationBuilder.UpdateData(
                table: "Schedules",
                keyColumn: "ScheduleId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2024, 12, 12, 18, 59, 54, 81, DateTimeKind.Local).AddTicks(2086));
        }
    }
}
