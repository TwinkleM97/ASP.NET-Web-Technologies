﻿using System.ComponentModel.DataAnnotations;

namespace ClinicApp.Models
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Please enter a username.")]
        [StringLength(255)]
        public string? Username { get; set; }

        [Required(ErrorMessage = "Please enter a password.")]
        [RegularExpression(@"^(?=.*\d)(?=.*[^a-zA-Z0-9])(?=.*[a-zA-Z]).{6,}$",
                ErrorMessage = "The password must be at least 6 char long, with atleast 1 digit, and one special character")]
        [DataType(DataType.Password)]
        [Compare("ConfirmPassword")]
        public string? Password { get; set; }

        [Required(ErrorMessage = "Please confirm your password.")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        public string? ConfirmPassword { get; set; }
    }
}
