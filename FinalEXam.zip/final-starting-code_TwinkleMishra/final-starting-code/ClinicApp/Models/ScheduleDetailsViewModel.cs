﻿using Clinic.Entities;

namespace ClinicApp.Models
{
    public class ScheduleDetailsViewModel
    {
        public Schedule ActiveSchedule { get; set; }
        public Clinician NewClinician { get; set; }
        public Appointment NewAppointment { get; set; }
        public int InPersonCount { get; set; }
        public int PhoneCount { get; set; }
        public int VideoCount { get; set; }
    }
}
