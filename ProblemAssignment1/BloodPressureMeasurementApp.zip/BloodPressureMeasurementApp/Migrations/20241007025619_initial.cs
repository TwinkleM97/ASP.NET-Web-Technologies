﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BloodPressureMeasurementApp.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Positions",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Positions", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "BPMeasurements",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Systolic = table.Column<int>(type: "int", nullable: false),
                    Diastolic = table.Column<int>(type: "int", nullable: false),
                    DateTaken = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PositionID = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BPMeasurements", x => x.ID);
                    table.ForeignKey(
                        name: "FK_BPMeasurements_Positions_PositionID",
                        column: x => x.PositionID,
                        principalTable: "Positions",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Positions",
                columns: new[] { "ID", "Name" },
                values: new object[,]
                {
                    { "1", "Sitting" },
                    { "2", "Standing" },
                    { "3", "Lying Down" }
                });

            migrationBuilder.InsertData(
                table: "BPMeasurements",
                columns: new[] { "ID", "DateTaken", "Diastolic", "PositionID", "Systolic" },
                values: new object[,]
                {
                    { 1, new DateTime(2023, 1, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), 83, "1", 123 },
                    { 2, new DateTime(2023, 2, 21, 0, 0, 0, 0, DateTimeKind.Unspecified), 92, "3", 130 },
                    { 3, new DateTime(2023, 3, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), 101, "2", 164 },
                    { 4, new DateTime(2023, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 140, "1", 181 },
                    { 5, new DateTime(2023, 4, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 120, "3", 173 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_BPMeasurements_PositionID",
                table: "BPMeasurements",
                column: "PositionID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BPMeasurements");

            migrationBuilder.DropTable(
                name: "Positions");
        }
    }
}
