﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BloodPressureMeasurementApp.Models
{
    public class BPMeasurement
    {
        [Key] // ID is primary key
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; } 

        [Required]
        [Range(20, 400, ErrorMessage = "Systolic should be between 20 and 400")]
        public int Systolic { get; set; }

        [Required]
        [Range(10, 300, ErrorMessage = "Diastolic should be between 10 and 300.")]
        public int Diastolic { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DateTaken { get; set; }

        public string PositionID { get; set; }
        public Position? Position { get; set; }

        public string Category
        {
            get
            {
                if (Systolic < 120 && Diastolic < 80)
                    return "Normal";
                else if (Systolic >= 120 && Systolic <= 129 && Diastolic < 80)
                    return "Elevated";
                else if (Systolic >= 130 && Systolic <= 139 || Diastolic >= 80 && Diastolic <= 89)
                    return "Hypertension Stage 1";
                else if (Systolic >= 140 || Diastolic >= 90)
                    return "Hypertension Stage 2";
                else if (Systolic > 180 || Diastolic > 120)
                    return "Hypertensive Crisis";
                else
                    return "Unknown";
            }
        }
    }
}

