﻿
using BloodPressureMeasurementApp.Models; // For BPMeasurement model
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace BloodPressureMeasurementApp.Controllers
{
    public class BPMController : Controller
    {
        private readonly BPMDbContext _context;

        public BPMController(BPMDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var measurements = _context.BPMeasurements.Include(b => b.Position).ToList();
            return View(measurements);
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            var measurement = _context.BPMeasurements.Include(b => b.Position).FirstOrDefault(m => m.ID == id);
            if (measurement == null) return NotFound();
            return View(measurement);
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewData["PositionID"] = new SelectList(_context.Positions, "ID", "Name");
            return View(new BPMeasurement());
        }

        [HttpPost]
        public IActionResult Create(BPMeasurement bPMeasurement) 
        {
            if (ModelState.IsValid)
            {
                _context.BPMeasurements.Add(bPMeasurement);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PositionID"] = new SelectList(_context.Positions, "ID", "Name", bPMeasurement.PositionID);
            return View(bPMeasurement);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var measurement = _context.BPMeasurements.Find(id);
            if (measurement == null) return NotFound();
            ViewData["PositionID"] = new SelectList(_context.Positions, "ID", "Name", measurement.PositionID);
            return View(measurement);
        }

        [HttpPost]
        public IActionResult Edit(BPMeasurement bPMeasurement) // Use the correct model type
        {
            if (ModelState.IsValid)
            {
                _context.BPMeasurements.Update(bPMeasurement);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PositionID"] = new SelectList(_context.Positions, "ID", "Name", bPMeasurement.PositionID);
            return View(bPMeasurement);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var measurement = _context.BPMeasurements.Include(b => b.Position).FirstOrDefault(m => m.ID == id);
            if (measurement == null) return NotFound();
            return View(measurement);
        }

        [HttpPost]
        public IActionResult DeletionConfirmed(int id)
        {
            var measurement = _context.BPMeasurements.Find(id);
            if (measurement != null)
            {
                _context.BPMeasurements.Remove(measurement);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

    }
}
