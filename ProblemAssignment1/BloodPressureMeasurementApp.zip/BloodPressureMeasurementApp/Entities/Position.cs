﻿namespace BloodPressureMeasurementApp.Models
{
    public class Position
    {
        public string ID { get; set; }
        public string Name { get; set; }

        public ICollection<BPMeasurement> BPMeasurements { get; set; }
    }
}
