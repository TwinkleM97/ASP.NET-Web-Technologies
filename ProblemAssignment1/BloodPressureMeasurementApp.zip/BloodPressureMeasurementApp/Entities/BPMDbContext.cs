﻿using Microsoft.EntityFrameworkCore;

namespace BloodPressureMeasurementApp.Models
{
    public class BPMDbContext : DbContext
    {
        public BPMDbContext(DbContextOptions<BPMDbContext> options)
   : base(options)
        {
        }
        //Two tables will be created in Database BPMeasurements, Positions
        public DbSet<BPMeasurement> BPMeasurements { get; set; }
        public DbSet<Position> Positions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Position>().HasData(
                new Position { ID = "1", Name = "Sitting" },
                new Position { ID = "2", Name = "Standing" },
                new Position { ID = "3", Name = "Lying Down" }
            );

            modelBuilder.Entity<BPMeasurement>().HasData(
                new BPMeasurement { ID = 1, Systolic = 123, Diastolic = 83, DateTaken = new DateTime(2023, 1, 11), PositionID = "1" },
                new BPMeasurement { ID = 2, Systolic = 130, Diastolic = 92, DateTaken = new DateTime(2023, 2, 21), PositionID = "3" },
                new BPMeasurement { ID = 3, Systolic = 164, Diastolic = 101, DateTaken = new DateTime(2023, 3, 13), PositionID = "2" },
                new BPMeasurement { ID = 4, Systolic = 181, Diastolic = 140, DateTaken = new DateTime(2023, 5, 15), PositionID = "1" },
                new BPMeasurement { ID = 5, Systolic = 173, Diastolic = 120, DateTaken = new DateTime(2023, 4, 15), PositionID = "3" }
            );
        }



    }
}

