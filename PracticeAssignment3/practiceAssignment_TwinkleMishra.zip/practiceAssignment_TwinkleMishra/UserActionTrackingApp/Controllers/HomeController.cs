﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

using UserActionTrackingApp.Models;
using UserActionTrackingApp.Services;

namespace UserActionTrackingApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly PageVisitCountService _pageVisitCountService;

        public HomeController(PageVisitCountService pageVisitCountService)
        {
            _pageVisitCountService = pageVisitCountService;
        }

        public IActionResult Index()
        {
            // Tracking and incrementing the visit count for Home page
            var totalHomeVisits = _pageVisitCountService.GetAndIncrementTotalVisitCount("home_page_visit_count");
            var sessionHomeVisits = _pageVisitCountService.GetAndIncrementSessionVisitCount("home_page_visit_count");

            // Pass the visit counts to the view through ViewBag
            ViewBag.UserTrackingMessage = $"You have visited this page a total of {totalHomeVisits} times, and {sessionHomeVisits} of those visits are from this current session.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}