﻿using Microsoft.AspNetCore.Mvc;

using UserActionTrackingApp.Models;
using UserActionTrackingApp.Services;

namespace UserActionTrackingApp.Controllers
{
    public class OtherController : Controller
    {
        private readonly PageVisitCountService _pageVisitCountService;

        public OtherController(PageVisitCountService pageVisitCountService)
        {
            _pageVisitCountService = pageVisitCountService;
        }

        public IActionResult Index()
        {
            // Track and increment the total visit count for the Other page
            var totalOtherVisits = _pageVisitCountService.GetAndIncrementTotalVisitCount("other_page_visit_count");
            var sessionOtherVisits = _pageVisitCountService.GetAndIncrementSessionVisitCount("other_page_visit_count");

            // Pass the visit counts to the view via ViewBag
            ViewBag.UserTrackingMessage = $"You have visited this page a total of {totalOtherVisits} times, and {sessionOtherVisits} of those visits are from this current session.";

            return View();
        }
    }
}
