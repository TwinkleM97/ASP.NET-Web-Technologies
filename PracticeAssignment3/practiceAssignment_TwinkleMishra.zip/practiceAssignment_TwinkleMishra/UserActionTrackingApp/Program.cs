using UserActionTrackingApp.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Register the PageVisitCountService as scoped
builder.Services.AddScoped<PageVisitCountService>();

// Register IHttpContextAccessor so the PageVisitCountService can access HttpContext (for session and cookies)
builder.Services.AddHttpContextAccessor();

// Configure session timeout to 5 minutes for testing
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(5); // Set session timeout to 5 minutes
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts(); // HSTS (HTTP Strict Transport Security)
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Enable session middleware
app.UseSession();

app.UseCookiePolicy(); // Optionally, enable cookie policy for GDPR compliance

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();