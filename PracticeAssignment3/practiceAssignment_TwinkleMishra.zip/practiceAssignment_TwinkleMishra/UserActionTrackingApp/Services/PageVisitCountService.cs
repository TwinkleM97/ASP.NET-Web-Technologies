﻿using Newtonsoft.Json;

namespace UserActionTrackingApp.Services
{
    public class PageVisitCountService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PageVisitCountService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public int GetAndIncrementTotalVisitCount(string pageName)
        {
            // Retrieving total visit count from cookies, or initializing if not found
            var totalCount = GetVisitCountFromCookie(pageName);
            totalCount++;
            SaveVisitCountToCookie(pageName, totalCount);
            return totalCount;
        }

        public int GetAndIncrementSessionVisitCount(string pageName)
        {
            // Retrieve the current session count, or initialize to 0 if not set
            int sessionCount = _httpContextAccessor.HttpContext.Session.GetInt32(pageName) ?? 0;

            // Incrementing the session count
            sessionCount++;

            // Storing the updated session count
            _httpContextAccessor.HttpContext.Session.SetInt32(pageName, sessionCount);

            return sessionCount;
        }

        // Helper methods for cookie management
        private int GetVisitCountFromCookie(string pageName)
        {
            var cookieValue = _httpContextAccessor.HttpContext.Request.Cookies[pageName];
            if (string.IsNullOrEmpty(cookieValue))
            {
                return 0; // If no cookie, initialize the count to 0
            }

            return int.TryParse(cookieValue, out var count) ? count : 0;
        }

        private void SaveVisitCountToCookie(string pageName, int count)
        {
            var cookieOptions = new CookieOptions
            {
                Expires = DateTime.Now.AddDays(30), // Set cookie expiration to 30 days
                HttpOnly = true //  cookies is only accessible via HTTP
            };

            _httpContextAccessor.HttpContext.Response.Cookies.Append(pageName, count.ToString(), cookieOptions);
        }
    }
}