
using BPApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using BPApp.Entities;

namespace BPApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private BpmeasurementsContext _bpmeasurementsContext;

        public BpmeasurementsContext BpmeasurementsContext { get => _bpmeasurementsContext; set => _bpmeasurementsContext = value; }

        public HomeController(ILogger<HomeController> logger, BpmeasurementsContext bpmeasurementsContext)
        {
            _logger = logger;
            BpmeasurementsContext = bpmeasurementsContext;
        }

        public IActionResult Index()
        {
            // Fetch bp measuremnet data from the database
            // Including the related MeasurementPosition entity for each Bpmeasurement
            // Order the results by MeasurementDate in descending order (most recent first)

            var bpm = BpmeasurementsContext.Bpmeasurements.Include(x => x.MeasurementPosition
                ).OrderByDescending(x => x.MeasurementDate).ToList();// Converting the query result to a list

            //// Passing the list of measurements to the "Index" view for rendering
            return View("Index", bpm);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
