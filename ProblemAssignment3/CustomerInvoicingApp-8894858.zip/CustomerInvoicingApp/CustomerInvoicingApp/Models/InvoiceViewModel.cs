﻿namespace CustomerInvoicingApp.Models
{
    public class InvoiceViewModel
    {
        public Core.Invoicing.Entities.Customer? Customer { get; set; }

        public IEnumerable<Core.Invoicing.Entities.Invoice>? Invoices { get; set; }

        // The invoice selected to be shwown or edited
        public Core.Invoicing.Entities.Invoice? SelectedInvoice { get; set; }

        //Collection of payment terms that can be selected
        public IEnumerable<Core.Invoicing.Entities.PaymentTerms>? PaymentTerms { get; set; }
    }
}

