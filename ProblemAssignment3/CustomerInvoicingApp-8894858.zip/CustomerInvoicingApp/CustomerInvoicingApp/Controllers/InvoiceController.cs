﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using CustomerInvoicingApp.Models;
using CustomerInvoicingApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace CustomerInvoicingApp.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly IInvoiceService _invoiceService;
        private readonly ICustomerService _customerService;
        private readonly IPaymentTermsService _paymentTermsService;

        // Constructor to initialize services for the Invoice service
        public InvoiceController(IInvoiceService invoiceService, ICustomerService customerService, IPaymentTermsService paymentTermsService)
        {
            _invoiceService = invoiceService;
            _customerService = customerService;
            _paymentTermsService = paymentTermsService;
        }

        // This method gets invoices and customer details and returns the Index view with the invoice data.
        public async Task<IActionResult> Index(int customerId, int? invoiceId = null)
        {
            var invoices = await _invoiceService.GetInvoicesByCustomerId(customerId);
            var customer = await _customerService.GetCustomerByIdAsync(customerId);
            var paymentTerms = await _paymentTermsService.GetAllPaymentTermsAsync();
            if (paymentTerms == null || paymentTerms.Count == 0)
            {
                throw new Exception("No payment terms found.");
            }
            var selectedInvoice = invoiceId.HasValue ? invoices.FirstOrDefault(i => i.InvoiceId == invoiceId) : invoices.FirstOrDefault();
            var viewModel = new InvoiceViewModel
            {
                Customer = customer,
                Invoices = invoices,
                SelectedInvoice = selectedInvoice,
                PaymentTerms = paymentTerms
            };
            ViewBag.Group = Request.Query["group"].ToString();
            return View(viewModel);
        }

        // This method adds a new invoice and redirects back to the Index view.
        [HttpPost]
        public async Task<IActionResult> AddInvoice(Invoice invoice, InvoiceViewModel invoiceViewModel)
        {
            invoice.PaymentTermsId = invoiceViewModel.SelectedInvoice.PaymentTermsId;
            invoice.InvoiceDate = invoiceViewModel.SelectedInvoice.InvoiceDate; // Ensure the date is set
            if (ModelState.IsValid)
            {
                await _invoiceService.AddInvoice(invoice);
                return RedirectToAction("Index", new { customerId = invoice.CustomerId });
            }
            return RedirectToAction("Index", new { customerId = invoice.CustomerId });
        }

        // This method gets invoice line items and returns a partial view to display them
        public async Task<IActionResult> GetInvoiceLineItems(int invoiceId)
        {
            var invoice = await _invoiceService.GetInvoiceById(invoiceId);
            if (invoice == null)
            {
                return NotFound();
            }
            return PartialView("_InvoiceLineItems", invoice);
        }

        // This method adds a new line item to an existing invoice and redirects us to the Index view.
        [HttpPost]
        public async Task<IActionResult> AddLineItem(InvoiceLineItem lineItem, int CustomerId, int InvoiceId)
        {
            lineItem.InvoiceId = InvoiceId;

            // Add new line item
            await _invoiceService.AddLineItem(lineItem);

            // Update the PaymentTotal for the invoice
            var invoice = await _invoiceService.GetInvoiceById(InvoiceId);
            if (invoice != null)
            {
                invoice.PaymentTotal = invoice.InvoiceLineItems.Sum(i => i.Amount ?? 0);
                await _invoiceService.UpdateInvoice(invoice);
            }

            return RedirectToAction("Index", new { customerId = CustomerId, invoiceId = InvoiceId });
        }


    }
}
