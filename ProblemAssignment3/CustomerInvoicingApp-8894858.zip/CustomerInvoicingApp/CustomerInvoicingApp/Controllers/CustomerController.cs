﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using CustomerInvoicingApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace CustomerInvoicingApp.Controllers
{
        public class CustomerController : Controller
        {
            private readonly ICustomerService _customerService;

            // Constructor to initialize the customer service
            public CustomerController(ICustomerService customerService)
            {
                _customerService = customerService;
            }

        // Displays the list of customers, filtered by a group optionally
        public async Task<IActionResult> Index(string group, string currentGroup, string message)
            {
                var customers = await _customerService.GetCustomersAsync();

                // Reset group filter if the same group is selected
                if (!string.IsNullOrEmpty(currentGroup) && currentGroup == group)
                {
                    group = null;
                }

                // Apply group filter
                if (!string.IsNullOrEmpty(group))
                {
                    var groupings = new Dictionary<string, char[]>
                {
                    { "A-E", new[] { 'A', 'B', 'C', 'D', 'E' } },
                    { "F-K", new[] { 'F', 'G', 'H', 'I', 'J', 'K' } },
                    { "L-R", new[] { 'L', 'M', 'N', 'O', 'P', 'Q', 'R' } },
                    { "S-Z", new[] { 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' } }
                };

                    if (groupings.ContainsKey(group))
                    {
                        customers = customers.Where(c => groupings[group].Contains(char.ToUpper(c.Name[0]))).ToList();
                    }
                }

                ViewBag.Group = group;
                ViewBag.CurrentGroup = group;
                ViewBag.Message = message;

                return View(customers);
            }

            // Showing the form to add a new customer
            public IActionResult Add()
            {
                var customer = new Customer(); // CustomerId will be null for new entries
                return View(customer);
            }

            [HttpPost]
            [ValidateAntiForgeryToken]
            public async Task<IActionResult> Add(Customer customer)
            {
                // Ensure CustomerId is not validated for new customers
                ModelState.Remove(nameof(Customer.CustomerId));

                if (!ModelState.IsValid)
                {
                    return View(customer);
                }

                await _customerService.AddCustomerAsync(customer);

                // Add success message to TempData
                TempData["SuccessMessage"] = $"Customer '{customer.Name}' added successfully!";
                return RedirectToAction(nameof(Index));
            }

            // Shows the form to edit an existing customer
            public async Task<IActionResult> Edit(int id)
            {
                var customer = await _customerService.GetCustomerByIdAsync(id);
                if (customer == null)
                {
                    return NotFound();
                }
                return View(customer);
            }

            [HttpPost]
            [ValidateAntiForgeryToken]
            public async Task<IActionResult> Edit(Customer customer)
            {
                if (!ModelState.IsValid)
                {
                    return View(customer);
                }

                await _customerService.UpdateCustomerAsync(customer);

                // Adding success message to TempData
                TempData["SuccessMessage"] = $"Customer '{customer.Name}' updated successfully!";
                return RedirectToAction(nameof(Index));
            }

            // Soft deleting a customer by setting IsDeleted flag to true
            public async Task<IActionResult> Delete(int id)
            {
                await _customerService.SoftDeleteCustomerAsync(id);
                TempData["SuccessMessage"] = "Customer deleted successfully!";
                return RedirectToAction(nameof(Index));
            }

            // Undo the soft delete by setting the IsDeleted flag to false
            public async Task<IActionResult> UndoDelete(int id)
            {
                var customer = await _customerService.GetCustomerByIdAsync(id);
                if (customer != null)
                {
                    customer.IsDeleted = false;
                    await _customerService.UpdateCustomerAsync(customer);
                    TempData["SuccessMessage"] = "Customer restored successfully!";
                }
                return RedirectToAction(nameof(Index));
            }
        }
    }
