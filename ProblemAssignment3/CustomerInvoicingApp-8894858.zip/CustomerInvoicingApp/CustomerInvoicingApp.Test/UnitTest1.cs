using CustomerInvoicingApp.Core.Invoicing.Entities;
using CustomerInvoicingApp.Services;
using System.Net.Http;
using Xunit;
using System.Collections.Generic;
using System.Threading.Tasks;
using CustomerInvoicingApp.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc;

namespace CustomerInvoicingApp.Test
{
    public class CustControllerTests
    {
        // Test implementation of the ICustomerService interface for unit testing
        private class TestCustomerService : ICustomerService
        {
            // Mock method to simulate adding a customer
            public Task AddCustomerAsync(Customer customer) => Task.CompletedTask;

            // Mock method to simulate updating a customer
            public Task UpdateCustomerAsync(Customer customer) => Task.CompletedTask;

            // Mock method to simulate retrieving a customer by ID
            public Task<Customer> GetCustomerByIdAsync(int id) => Task.FromResult(new Customer { CustomerId = id, Name = $"Customer{id}" });

            // Mock method to simulate fetching a list of customers
            public Task<List<Customer>> GetCustomersAsync() => Task.FromResult(new List<Customer>
        {
            new Customer { CustomerId = 1, Name = "Customer1" },
            new Customer { CustomerId = 2, Name = "Customer2" }
        });

            // Mock method to simulate retrieving a customer with invoices (not implemented)
            public Task<Customer> GetCustomerWithInvoicesAsync(int id)
            {
                throw new NotImplementedException();
            }

            // Mock method to simulate soft deleting a customer (not implemented)
            public Task SoftDeleteCustomerAsync(int id)
            {
                throw new NotImplementedException();
            }
        }

        // Unit test for the Index method of CustomerController
        [Fact]
        public async Task Index_ReturnsViewResult_WithListOfCustomers()
        {
            // Arrange
            var service = new TestCustomerService(); // Creating an instance of the test customer service
            var controller = new CustomerController(service); // Creating an instance of the CustomerController with the test service
            var tempData = new TempDataDictionary(new DefaultHttpContext(),
                                                  new MockTempDataProvider());
            controller.TempData = tempData;

            // Act
            var result = await controller.Index(null, null, null); // Calling the Index method

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result); // Asserting that the result is a ViewResult
            var model = Assert.IsAssignableFrom<IEnumerable<Customer>>(viewResult.ViewData.Model); // Asserting that the model is a list of customers
            Assert.Equal(2, model.Count()); // Assert that the model contains 2 customers
        }

        // Unit testing for the Add method of CustomerController
        [Fact]
        public void Add_ReturnsViewResult()
        {
            // Arrange
            var service = new TestCustomerService();
            var controller = new CustomerController(service);
            var tempData = new TempDataDictionary(new DefaultHttpContext(), new MockTempDataProvider());
            controller.TempData = tempData;

            // Act
            var result = controller.Add();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        // Unit testing for the Edit method of CustomerController
        [Fact]
        public async Task Edit_ReturnsViewResult_WithCustomer()
        {
            // Arrange
            var service = new TestCustomerService();
            var controller = new CustomerController(service);
            var tempData = new TempDataDictionary(new DefaultHttpContext(), new MockTempDataProvider());
            controller.TempData = tempData;

            // Act
            var result = await controller.Edit(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<Customer>(viewResult.ViewData.Model);
            Assert.Equal(1, model.CustomerId);
        }

        // Implementation of ITempDataProvider for unit testing
        public class MockTempDataProvider : ITempDataProvider
        {
            public IDictionary<string, object> LoadTempData(HttpContext context) => new Dictionary<string, object>();

            public void SaveTempData(HttpContext context, IDictionary<string, object> values) { }
        }
    }
}
