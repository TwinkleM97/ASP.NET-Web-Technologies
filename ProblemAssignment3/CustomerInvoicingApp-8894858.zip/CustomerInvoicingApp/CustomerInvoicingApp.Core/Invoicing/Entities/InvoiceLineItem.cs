﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Core.Invoicing.Entities
{
    public class InvoiceLineItem
    {
        public int InvoiceLineItemId { get; set; } // Primary key

        public double? Amount { get; set; }

        public string? Description { get; set; }

        // FK: Foreign key to Invoice
        public int InvoiceId { get; set; }
        public Invoice Invoice { get; set; } // Navigation property for Invoice
    }
}
