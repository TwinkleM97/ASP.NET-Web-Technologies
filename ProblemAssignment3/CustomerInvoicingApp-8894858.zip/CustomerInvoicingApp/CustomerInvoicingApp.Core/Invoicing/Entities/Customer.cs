﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Core.Invoicing.Entities
{
    public class Customer
    {
        [ScaffoldColumn(false)]
        public int? CustomerId { get; set; } // PK

      [Required(ErrorMessage = "CustName is required")]
        public string Name { get; set; } = null!;

        [Required(ErrorMessage = "Address 1 is required")]
        public string? Address1 { get; set; }

        public string? Address2 { get; set; }

        [Required(ErrorMessage = "City is required")]
        public string? City { get; set; } = null!;

        [Required(ErrorMessage = "Province/State is required")]
        [RegularExpression(@"^[A-Za-z]{2}$", ErrorMessage = "Province/State must be a 2-letter code (e.g ON)")]
        public string? ProvinceOrState { get; set; } = null!;


        [Required(ErrorMessage = "Zip/Postal code is required.")]
        [RegularExpression(@"^\d{5}(-\d{4})?$|^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$",
        ErrorMessage = "Postal code must be in one of this formats: 12345, 12345-6789 (US), or A1A 1A1 (Canada)")]
        public string? ZipOrPostalCode { get; set; } = null!;


        [Required(ErrorMessage = "Phone number is required.")]
        [RegularExpression(@"^\+?1?[-.\s]?(\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}$",
        ErrorMessage = "Phone number must be in a valid format: 123-456-7890, (123) 456-7890, or +1 123-456-7890")]
        public string? Phone { get; set; }


        public string? ContactLastName { get; set; }

        public string? ContactFirstName { get; set; }

        [EmailAddress(ErrorMessage = "Email address format is invalid")]
        public string? ContactEmail { get; set; }

        public bool IsDeleted { get; set; } = false;

        public ICollection<Invoice>? Invoices { get; set; } // Navigation property - Collection of invoices associated with the customer
    }
}

    