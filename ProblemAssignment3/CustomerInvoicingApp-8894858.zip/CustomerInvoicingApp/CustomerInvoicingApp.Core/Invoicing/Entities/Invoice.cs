﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Core.Invoicing.Entities
{
    public class Invoice
    {
        public int InvoiceId { get; set; }  // Primary key
        public DateTime? InvoiceDate { get; set; }
        public DateTime? InvoiceDueDate
        {
            get
            {
                return InvoiceDate?.AddDays(Convert.ToDouble(PaymentTerms?.DueDays));
            }
        }
        public double? PaymentTotal { get; set; } = 0.0;
        public DateTime? PaymentDate { get; set; }

        // FK: Foreign key to PaymentTerms
        public int PaymentTermsId { get; set; }
        public PaymentTerms? PaymentTerms { get; set; }  // Navigation property for PaymentTerms

        // FK:  Foreign key to Customer
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }  // Navigation property for Customer

        public ICollection<InvoiceLineItem> InvoiceLineItems { get; set; } = new List<InvoiceLineItem>(); // Navigation property- Collection of line items associated with the invoice
    }
}
