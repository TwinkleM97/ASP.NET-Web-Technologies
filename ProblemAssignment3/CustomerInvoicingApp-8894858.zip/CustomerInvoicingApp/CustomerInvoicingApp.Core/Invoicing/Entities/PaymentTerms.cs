﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Core.Invoicing.Entities
{
    public class PaymentTerms
    {
        public int PaymentTermsId { get; set; } // Primary key

        public string Description { get; set; }

        public int DueDays { get; set; }

        public ICollection<Invoice> Invoices { get; set; } // Collection of Invoices associated with these payment terms
    }
}
