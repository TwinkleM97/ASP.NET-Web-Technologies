﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using CustomerInvoicingApp.Services.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CustomerInvoicingApp.Services
{
    public class CustomerService :  ICustomerService
    {
        private readonly ApplicationDbContext _context;

    // Constructor to initialize the ApplicationDbContext
    public CustomerService(ApplicationDbContext context)
    {
        _context = context;
    }

        // Getting list of customers that are not marked as deleted
        public async Task<List<Customer>> GetCustomersAsync()
        {
            var customers = await _context.Customers
                .Where(c => !c.IsDeleted)
                .ToListAsync();
            Console.WriteLine($"Retrieved {customers.Count} active customers");
            return customers;
        }



        // Gets a specific customer by its ID, including related invoices and paymentTerms
        public async Task<Customer> GetCustomerByIdAsync(int id)
    {
        return await _context.Customers
            .Include(c => c.Invoices)
            .ThenInclude(i => i.PaymentTerms) // Include payment terms through invoices
            .FirstOrDefaultAsync(c => c.CustomerId == id);
    }

    //This will update an existing customer in the database
    public async Task UpdateCustomerAsync(Customer customer)
    {
        _context.Customers.Update(customer);
        await _context.SaveChangesAsync();
    }

    // Getting a specific customer by its ID, including related invoices and invoicelineitems
    public async Task<Customer> GetCustomerWithInvoicesAsync(int id)
    {
        return await _context.Customers
            .Include(c => c.Invoices)
            .ThenInclude(i => i.InvoiceLineItems)
            .FirstOrDefaultAsync(c => c.CustomerId == id);
    }

        // Adds a new customer to the database
        public async Task AddCustomerAsync(Customer customer)
        {
            try
            {
                _context.Customers.Add(customer);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding customer: {ex.Message}");
                throw;
            }
        }


        // Soft deletes a customer by setting the IsDeleted flag to true
        public async Task SoftDeleteCustomerAsync(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer != null)
            {
                customer.IsDeleted = true;
                Console.WriteLine($"Customer {customer.Name} marked as deleted.");
                await _context.SaveChangesAsync();
            }
            else
            {
                Console.WriteLine($"Customer with ID {id} not found.");
            }
        }
    }
}

