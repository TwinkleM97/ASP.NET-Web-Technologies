﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using CustomerInvoicingApp.Services.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Services
{
    public class PaymentTermsService : IPaymentTermsService
    {
        private readonly ApplicationDbContext _context;

        // Constructor to initialize the ApplicationDbContext
        public PaymentTermsService(ApplicationDbContext context)
        {
            _context = context;
        }

        // Gets all payment terms from the database
        public async Task<List<PaymentTerms>> GetAllPaymentTermsAsync()
        {
            return await _context.PaymentTerms.ToListAsync();
        }

        // Getting a specific payment term by its ID
        public async Task<PaymentTerms> GetPaymentTermsByIdAsync(int id)
        {
            return await _context.PaymentTerms.FirstOrDefaultAsync(pt => pt.PaymentTermsId == id);
        }

        // Adds a new payment term to the database
        public async Task AddPaymentTermsAsync(PaymentTerms paymentTerms)
        {
            _context.PaymentTerms.Add(paymentTerms);
            await _context.SaveChangesAsync();
        }

        // Updates an existing payment term in the database
        public async Task UpdatePaymentTermsAsync(PaymentTerms paymentTerms)
        {
            _context.PaymentTerms.Update(paymentTerms);
            await _context.SaveChangesAsync();
        }

        // Will Delete a payment term from the database
        public async Task DeletePaymentTermsAsync(int id)
        {
            var paymentTerms = await _context.PaymentTerms.FindAsync(id);
            if (paymentTerms != null)
            {
                _context.PaymentTerms.Remove(paymentTerms);
                await _context.SaveChangesAsync();
            }
        }
    }
}
