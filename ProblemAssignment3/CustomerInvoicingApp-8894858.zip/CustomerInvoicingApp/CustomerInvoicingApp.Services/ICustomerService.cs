﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Services
{
    public interface ICustomerService
    {
        Task AddCustomerAsync(Customer customer);
        Task<Customer> GetCustomerByIdAsync(int id);
        Task<List<Customer>> GetCustomersAsync();
        Task<Customer> GetCustomerWithInvoicesAsync(int id);
        Task SoftDeleteCustomerAsync(int id);
        Task UpdateCustomerAsync(Customer customer);
    }
}
