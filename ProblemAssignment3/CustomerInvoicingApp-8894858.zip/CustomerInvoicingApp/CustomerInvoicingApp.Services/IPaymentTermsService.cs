﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Services
{
    public interface IPaymentTermsService
    {
        Task<List<PaymentTerms>> GetAllPaymentTermsAsync();
    }
}
