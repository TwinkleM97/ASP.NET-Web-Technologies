﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using CustomerInvoicingApp.Services.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly ApplicationDbContext _context;

        // Constructor to initialize the ApplicationDbContext
        public InvoiceService(ApplicationDbContext context)
        {
            _context = context;
        }

        // Adding a new invoice to the db
        public async Task AddInvoice(Invoice invoice)
        {
            var paymentTerms = await _context.PaymentTerms.FirstOrDefaultAsync(pt => pt.PaymentTermsId == invoice.PaymentTermsId);
            if (paymentTerms != null)
            {
                invoice.PaymentTerms = paymentTerms; // Ensure PaymentTerms is set
                _context.Invoices.Add(invoice);
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("Invalid PaymentTermsId");
            }
        }

        // Adds a new line item to an existing invoice
        public async Task AddLineItem(InvoiceLineItem lineItem)
        {
            // Add the line item
            _context.InvoiceLineItems.Add(lineItem);

            // Find the associated invoice
            var invoice = await _context.Invoices
                .Include(i => i.InvoiceLineItems) // Include line items for recalculation
                .FirstOrDefaultAsync(i => i.InvoiceId == lineItem.InvoiceId);

            if (invoice != null)
            {
                // Will Update the PaymentTotal to be the sum of all line item amounts
                invoice.PaymentTotal = invoice.InvoiceLineItems.Sum(li => li.Amount ?? 0);
            }

            await _context.SaveChangesAsync();
        }
        public async Task UpdateInvoice(Invoice invoice)
        {
            _context.Invoices.Update(invoice);
            await _context.SaveChangesAsync();
        }


        // Gets a list of invoices for a specific customer
        public async Task<List<Invoice>> GetInvoicesByCustomerId(int customerId)
        {
            return await _context.Invoices
                .Where(i => i.CustomerId == customerId)
                .Include(i => i.PaymentTerms)
                .Include(i => i.InvoiceLineItems)
                .ToListAsync();
        }

        // Gets a specific invoice by its ID
        public async Task<Invoice> GetInvoiceById(int invoiceId)
        {
            return await _context.Invoices
                .Include(i => i.PaymentTerms) // Ensure PaymentTerms is included
                .Include(i => i.InvoiceLineItems) // Ensure InvoiceLineItems is included
                .FirstOrDefaultAsync(i => i.InvoiceId == invoiceId);
        }
    }
}

