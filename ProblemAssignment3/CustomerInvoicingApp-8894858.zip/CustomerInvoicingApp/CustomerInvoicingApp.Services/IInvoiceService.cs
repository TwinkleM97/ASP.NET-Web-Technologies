﻿using CustomerInvoicingApp.Core.Invoicing.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingApp.Services
{
    public interface IInvoiceService
    {
        Task AddInvoice(Invoice invoice);
        Task AddLineItem(InvoiceLineItem lineItem);
        Task<List<Invoice>> GetInvoicesByCustomerId(int customerId);
        Task<Invoice> GetInvoiceById(int invoiceId);
        Task UpdateInvoice(Invoice invoice);
    }
}
