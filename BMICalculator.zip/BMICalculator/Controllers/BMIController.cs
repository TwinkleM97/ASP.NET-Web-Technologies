﻿using Microsoft.AspNetCore.Mvc;
using BMICalculator.Models;

namespace BMICalculator.Controllers
{
    public class BMIController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new BMIViewModel());
        }
        [HttpPost]
        public IActionResult Index(BMIViewModel para1)
        {
            if (ModelState.IsValid)
            {

                para1.BMI = BMIViewModel.CalculateBMI(para1.Height, para1.Weight);

                // and the summary:
                para1.BMISummary = BMIViewModel.GetBmiResultSummary(para1.BMI);
            }
                return View(para1);

            }
        }
    }

