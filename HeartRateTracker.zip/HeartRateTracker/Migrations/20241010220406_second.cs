﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HeartRateTracker.Migrations
{
    /// <inheritdoc />
    public partial class second : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "HeartRateMeasurements",
                keyColumn: "HeartRateMeasurementId",
                keyValue: 1,
                column: "MeasurementDate",
                value: new DateTime(2024, 10, 5, 18, 4, 5, 572, DateTimeKind.Local).AddTicks(8841));

            migrationBuilder.UpdateData(
                table: "HeartRateMeasurements",
                keyColumn: "HeartRateMeasurementId",
                keyValue: 2,
                column: "MeasurementDate",
                value: new DateTime(2024, 9, 29, 18, 4, 5, 572, DateTimeKind.Local).AddTicks(8885));

            migrationBuilder.UpdateData(
                table: "HeartRateMeasurements",
                keyColumn: "HeartRateMeasurementId",
                keyValue: 3,
                column: "MeasurementDate",
                value: new DateTime(2024, 9, 20, 18, 4, 5, 572, DateTimeKind.Local).AddTicks(8887));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "HeartRateMeasurements",
                keyColumn: "HeartRateMeasurementId",
                keyValue: 1,
                column: "MeasurementDate",
                value: new DateTime(2024, 10, 5, 18, 0, 33, 838, DateTimeKind.Local).AddTicks(928));

            migrationBuilder.UpdateData(
                table: "HeartRateMeasurements",
                keyColumn: "HeartRateMeasurementId",
                keyValue: 2,
                column: "MeasurementDate",
                value: new DateTime(2024, 10, 5, 18, 0, 33, 838, DateTimeKind.Local).AddTicks(974));

            migrationBuilder.UpdateData(
                table: "HeartRateMeasurements",
                keyColumn: "HeartRateMeasurementId",
                keyValue: 3,
                column: "MeasurementDate",
                value: new DateTime(2024, 10, 5, 18, 0, 33, 838, DateTimeKind.Local).AddTicks(977));
        }
    }
}
