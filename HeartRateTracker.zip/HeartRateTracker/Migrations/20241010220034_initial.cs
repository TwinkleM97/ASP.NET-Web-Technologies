﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace HeartRateTracker.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "HeartRateMeasurements",
                columns: table => new
                {
                    HeartRateMeasurementId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BPMValue = table.Column<int>(type: "int", nullable: false),
                    MeasurementDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HeartRateMeasurements", x => x.HeartRateMeasurementId);
                });

            migrationBuilder.InsertData(
                table: "HeartRateMeasurements",
                columns: new[] { "HeartRateMeasurementId", "BPMValue", "MeasurementDate", "Position" },
                values: new object[,]
                {
                    { 1, 148, new DateTime(2024, 10, 5, 18, 0, 33, 838, DateTimeKind.Local).AddTicks(928), "Standing" },
                    { 2, 190, new DateTime(2024, 10, 5, 18, 0, 33, 838, DateTimeKind.Local).AddTicks(974), "Standing" },
                    { 3, 77, new DateTime(2024, 10, 5, 18, 0, 33, 838, DateTimeKind.Local).AddTicks(977), "Sitting" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "HeartRateMeasurements");
        }
    }
}
