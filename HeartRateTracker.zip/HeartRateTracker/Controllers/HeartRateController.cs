﻿using HeartRateTracker.Entities;
using Microsoft.AspNetCore.Mvc;

namespace HeartRateTracker.Controllers
{
    public class HeartRateController : Controller
    {
        private HeartRateDbContext _heartRateDbcontext;

        public HeartRateController(HeartRateDbContext heartRateDbcontext)
        {
            _heartRateDbcontext = heartRateDbcontext;
        }
        [HttpGet("/heart-rate-measurements")]
        public IActionResult GetAllMeasurements()
        {
            var measurements = _heartRateDbcontext.HeartRateMeasurements.OrderByDescending(b => b.MeasurementDate).ToList();
            //orderby Desc

            return View("Items", measurements);
        }
        [HttpGet("/heart-rate-measurements/add-request")]
        public IActionResult GetAddMeasurementRequest()
        {

            return View("Add", new HeartRateMeasurement());
        }
        [HttpPost("/heart-rate-measurements")]
        public IActionResult AddNewMeasurement(HeartRateMeasurement heartRateMeasurement)
        {
            if (ModelState.IsValid)
            {
                _heartRateDbcontext.HeartRateMeasurements.Add(heartRateMeasurement);
                _heartRateDbcontext.SaveChanges();

                //Temp Data
                TempData["LastActionMessage"] = "The heart rate was created successfully";
                return RedirectToAction("GetAllMeasurements", "HeartRate");

            }
            return View("Add", new HeartRateMeasurement());
        }

        [HttpGet("/heart-rate-measurements/{id}/edit-request")]
        public IActionResult GetEditMeasurementRequestById(int id)
        {
            var msmt = _heartRateDbcontext.HeartRateMeasurements.Find(id);

            return View("Edit", msmt);
        }
        [HttpPost("/heart-rate-measurements/{id}/edit-request")]
        public IActionResult ProcessEditMeasurementRequest(int id, HeartRateMeasurement heartRateMeasurement)
        {
            if (id != heartRateMeasurement.HeartRateMeasurementId)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _heartRateDbcontext.HeartRateMeasurements.Update(heartRateMeasurement);
                _heartRateDbcontext.SaveChanges();

                //Temp Data
                TempData["LastActionMessage"] = "The heart rate was updated successfully";
                return RedirectToAction("GetAllMeasurements", "HeartRate");

            }
            return View("Edit", heartRateMeasurement);
        }

        [HttpGet("/heart-rate-measurements/{id}")]
        public IActionResult GetMeasurementById(int id)
        {
            var msmt = _heartRateDbcontext.HeartRateMeasurements.Find(id);

            return View("Details", msmt);
        }
    }
}
