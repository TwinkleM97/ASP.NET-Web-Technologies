﻿using Microsoft.EntityFrameworkCore;

namespace HeartRateTracker.Entities
{
    public class HeartRateDbContext : DbContext
    {
        public HeartRateDbContext(DbContextOptions<HeartRateDbContext> options)
            :base(options) { }
        
        public DbSet<HeartRateMeasurement> HeartRateMeasurements { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<HeartRateMeasurement>().HasData(
                new HeartRateMeasurement()
                {
                    HeartRateMeasurementId = 1,
                    BPMValue = 148,
                    MeasurementDate = DateTime.Now.AddDays(-5),
                    Position ="Standing"
                },
                 new HeartRateMeasurement()
                 {
                HeartRateMeasurementId = 2,
                     BPMValue = 190,
                    MeasurementDate = DateTime.Now.AddDays(-11),
                    Position = "Standing"
                },
                  new HeartRateMeasurement()
                  {
                      HeartRateMeasurementId = 3,
                      BPMValue = 77,
                      MeasurementDate = DateTime.Now.AddDays(-20),
                      Position = "Sitting"
                  }

                );
        }
    }
}
