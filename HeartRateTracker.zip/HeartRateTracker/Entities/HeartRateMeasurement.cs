﻿using System.ComponentModel.DataAnnotations;

namespace HeartRateTracker.Entities
{
    public class HeartRateMeasurement
    {
        public int HeartRateMeasurementId { get; set; }
        [Required(ErrorMessage ="The BPM value is required")]
        [Range(30,300,ErrorMessage = "The BPM value must be between 30 and 300")]
        public int BPMValue { get;set; }

        [Required(ErrorMessage = "The Measurement Date is required")]
        public DateTime? MeasurementDate { get; set; }

        public string? Position { get; set; }
    }
}
